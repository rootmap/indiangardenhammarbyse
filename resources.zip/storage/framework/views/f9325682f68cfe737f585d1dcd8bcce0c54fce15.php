<?php $__env->startSection('title','Gallery'); ?>
<?php $__env->startSection('content'); ?>

<!--===| Gallery Banner Start|===-->
  
  <div class="container header-block">
    <div class="row justify-content-center cl-block">
      <div class="common_layout_title">
        <h2>Gallery</h2>
      </div>
    </div>
  </div>
  <!--===| Gallery Us Banner End|===-->

   <!--====| Shuffle Gallery Style Sta rt|====--> 
  <section class="galleri-wrapper section-gallery-padding">
    <div class="container">
      <div class="row"> 
      <div class="gallery-trigger">
          <ul id="filter">
             <li><a class="active" href="#" data-group="total">all</a></li> 
             <?php if(count($category)>0): ?>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><a href="#" data-group="<?php echo e($c->name); ?>"><?php echo e($c->name); ?></a></li> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php endif; ?>
          </ul> 
      </div>

      <div id="grid">
      <!-- portfolio-item -->
          <?php if(count($gallery)>0): ?>
              <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="portfolio-item col-xs-12 col-sm-6 col-md-3 fancybox" data-groups='["total", "<?php echo e($g->category_name); ?>"]'  href="<?php echo e(url('upload/gallery/'.$g->gallery_image)); ?>" data-fancybox-group="gallery">
                    <div class="portfolio grid">
                    <figure class="effect-cheff gallary-image">
                      <img src="<?php echo e(url('upload/gallery/small/'.$g->gallery_image)); ?>" class="img-responsive" style="height: 300px;" alt="Gallery 01"/>
                      <!-- <figcaption>
                        <div class="gallary-hover-text">
                          <a class="yellow-bar fancybox" href="<?php echo e(url('upload/gallery/'.$g->gallery_image)); ?>" data-fancybox-group="gallery"><i class="fa fa-search-plus"></i></a>
                          <p><?php echo e($g->gallery_content); ?></p>
                        </div>
                      </figcaption>     
                    </figure> -->
                  </div>      
                </div><!-- col-xs-12 -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        
      </div> <!-- grid -->
    </div><!-- row -->
  </div><!-- container -->
</section> 
<!--====| Shuffle Gallery Style End |====-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>