<?php if(session('status')): ?>
    <div class="alert alert-success successPlace alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <h5><i class="icon fas fa-check"></i> <?php echo e(session('status')); ?></h5>  
    </div>
    <script type="text/javascript">
        setTimeout(function(){
            $('.successPlace').fadeOut('slow');
        }, 5000);
    </script>
    <?php 
    Session::forget('status');
    ?>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success successPlace alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <h5><i class="icon fas fa-check"></i> <?php echo e(session('success')); ?></h5>  
    </div>
    <script type="text/javascript">
        setTimeout(function(){
            $('.successPlace').fadeOut('slow');
        }, 5000);
    </script>
    <?php 
    Session::forget('success');
    ?>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger allDanger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-ban"></i> Alert! <?php echo e(session('error')); ?></h5>
          
    </div>
    <script type="text/javascript">
        setTimeout(function(){
            $('.allDanger').fadeOut('slow');
        }, 5000);
    </script>
    <?php 
    Session::forget('error');
    ?>
<?php endif; ?>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger allDanger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fas fa-ban"></i> Alert! </h5>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?><br />
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <script type="text/javascript">
        setTimeout(function(){
            $('.allDanger').fadeOut('slow');
        }, 10000);
    </script>
<?php endif; ?>