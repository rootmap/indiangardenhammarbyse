<?php $__env->startSection("title","Create New Gallery"); ?>
<?php $__env->startSection("content"); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Gallery</h1>
      </div>
      <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('galleryphoto/list')); ?>">Gallery Data</a></li>
              <li class="breadcrumb-item active">Create New Gallery</li>
            </ol>
      </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make("admin.include.msg", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-8 offset-2">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Create New Gallery</h3>
            <div class="card-tools">
              <ul class="pagination pagination-sm float-right">
                <li class="page-item"><a class="page-link bg-primary" href="<?php echo e(url('galleryphoto/list')); ?>"> Data <i class="fas fa-table"></i></a></li>
                <li class="page-item">
                  <a class="page-link  bg-primary" target="_blank" href="<?php echo e(url('galleryphoto/export/pdf')); ?>">
                    <i class="fas fa-file-pdf" data-toggle="tooltip" data-html="true"title="Pdf"></i>
                  </a>
                </li>
                <li class="page-item">
                  <a class="page-link  bg-primary" target="_blank" href="<?php echo e(url('galleryphoto/export/excel')); ?>">
                    <i class="fas fa-file-excel" data-toggle="tooltip" data-html="true"title="Excel"></i>
                  </a>
                </li>
              </ul>
            </div>            
        </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form action="<?php echo e(url('galleryphoto')); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          
            <div class="card-body">
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                          <label>Choose Category</label>
                          <select class="form-control select2" style="width: 100%;"  id="category" name="category">
                                <option value="">Please Select</option>
                                <?php if(isset($dataRow_Category)): ?>    
                                    <?php if(count($dataRow_Category)>0): ?>
                                        <?php $__currentLoopData = $dataRow_Category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($Category->id); ?>"><?php echo e($Category->name); ?></option>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endif; ?> 
                                
                          </select>
                        </div>
                    </div>

                    <div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label for="gallery_content">Gallery Content</label>
                        <input type="text" class="form-control" placeholder="Enter Gallery Content" id="gallery_content" name="gallery_content">
                      </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Enter Gallery Image</label>
                            <!-- <label for="customFile">Enter Gallery Image</label> -->

                            <div class="custom-file">
                              <input type="file" class="custom-file-input"  id="gallery_image" name="gallery_image">
                              <label class="custom-file-label" for="customFile">Enter Gallery Image</label>
                            </div>
                        </div>
                    </div>
                </div>       
            </div>
            <!-- /.card-body -->

            <div class="card-footer">
              <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Submit</button>
              <a class="btn btn-danger" href="<?php echo e(url('galleryphoto/create')); ?>"><i class="far fa-times-circle"></i> Reset</a>
            </div>
          </form>
        </div>
        <!-- /.card -->

      </div>
      <!--/.col (left) -->
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("css"); ?>
    
    <link rel="stylesheet" href="<?php echo e(url('admin/plugins/select2/css/select2.min.css')); ?>">
    
<?php $__env->stopSection(); ?>
        
<?php $__env->startSection("js"); ?>

    <script src="<?php echo e(url('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
    <script>
    $(document).ready(function(){
        $(".select2").select2();
    });
    </script>

    <script src="<?php echo e(url('admin/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
    <script>
    $(document).ready(function(){
        bsCustomFileInput.init();
    });
    </script>

<?php $__env->stopSection(); ?>
        
<?php echo $__env->make("admin.layout.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>