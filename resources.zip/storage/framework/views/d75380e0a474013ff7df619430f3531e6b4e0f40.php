<?php $__env->startSection("title","test2"); ?>
<?php $__env->startSection("content"); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Add New test2</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('test2/list')); ?>">test2 Data</a></li>
          <li class="breadcrumb-item active">Create New</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-8 offset-2">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">test2</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form action="<?php echo e(url('test2')); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          
            <div class="card-body">
                
                        <div class="form-group">
                            <label for="name">Name:</label>
                            <input type="text" id="name" name="name" class="form-control" placeholder="Enter Name">
                        </div><!-- end form-group -->
                        
                        <div class="form-group">
                            <label for="details">Details:</label>
                            <textarea class="form-control" id="details" name="details" rows="5" placeholder="Enter Details"></textarea>
                        </div><!-- end form-group -->
                        
                <div class="form-group">
                    <label for="image">image</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" id="image" name="image">
                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                      </div>
                    </div>
                </div>
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1" for="is_active" value="is_active">
                            <label class="form-check-label" for="
                                        &nbsp;<input type="checkbox"  id="is_active_0" name="is_active" value="">&nbsp;  &nbsp; 
                                    ">
                                        &nbsp;<input type="checkbox"  id="is_active_0" name="is_active" value="">&nbsp;  &nbsp; 
                                    </label>
                        </div>
                        
                    <div class="form-group">
                        
                        <div class="form-check lis">
                          <input class="form-check-input" type="radio"  disabled="disabled"  for="is_actives" value="Active,Inactive">
                          <label class="form-check-label">
                                        <input type="radio" class="form-check-input"
                                        id="is_actives_0" name="is_actives" value="">&nbsp;&nbsp; </label>
                        </div>
                        
                    </div>
                        
                        <div class="form-group">
                          <label for="category">Active,Inactive</label>
                          <select class="form-control select2" style="width: 100%;" id="category" name="category">
                            
        <option value="">Please select</option>
            <option 
            value="Active">Active</option>
            <option 
            value="Inactive">Inactive</option>
                          </select>
                        </div>
                        
            </div>
            <!-- /.card-body -->

            <div class="card-footer">
              <button type="submit" class="btn btn-primary">Submit</button>
              <button type="reset" class="btn btn-info">Reset</button>
            </div>
          </form>
        </div>
        <!-- /.card -->

      </div>
      <!--/.col (left) -->
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layout.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>