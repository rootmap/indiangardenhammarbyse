<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(url('dashboard')); ?>" class="brand-link">
      <img src="<?php echo e(url('admin/dist/img/AdminLTELogo.png')); ?>"
           alt="AdminLTE Logo"
           class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Admin Panel</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user (optional) -->
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="<?php echo e(url('dashboard')); ?>" class="nav-link <?php echo e(Request::path() == 'dashboard' ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-igloo"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item has-treeview <?php echo e(in_array(Request::path(),array('slider','weareopen','homepagevideo','homeorderdelivery','homedelivery'))?'menu-open':''); ?>">
            <a href="#" class="nav-link <?php echo e(in_array(Request::path(),array('slider','weareopen','homepagevideo','homeorderdelivery','homedelivery'))?'active':''); ?>">
              <i class="nav-icon fas fa-home"></i>
              <p>
                Home Page
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('slider')); ?>" class="nav-link <?php echo e(Request::path() == 'slider' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Slider</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('weareopen')); ?>" class="nav-link <?php echo e(Request::path() == 'weareopen' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>We are open</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('homepagevideo')); ?>" class="nav-link <?php echo e(Request::path() == 'homepagevideo' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Video</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('homeorderdelivery')); ?>" class="nav-link <?php echo e(Request::path() == 'homeorderdelivery' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Order Delivery</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('homedelivery')); ?>" class="nav-link <?php echo e(Request::path() == 'homedelivery' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Delivery</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview <?php echo e(in_array(Request::path(),array('ourhistorypageinfo','ourhistory'))?'menu-open':''); ?>">
            <a href="#" class="nav-link <?php echo e(in_array(Request::path(),array('ourhistorypageinfo','ourhistory'))?'active':''); ?>">
              <i class="nav-icon fas fa-book-open"></i>
              <p>
                Our History
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('ourhistorypageinfo')); ?>" class="nav-link <?php echo e(Request::path() == 'ourhistorypageinfo' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Our History Info</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('ourhistory')); ?>" class="nav-link <?php echo e(Request::path() == 'ourhistory' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Our History</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview <?php echo e(in_array(Request::path(),array('menupageinfo','category','menuitem'))?'menu-open':''); ?>">
            <a href="#" class="nav-link <?php echo e(in_array(Request::path(),array('menupageinfo','category','menuitem'))?'active':''); ?>">
              <i class="nav-icon fas fa-utensils"></i>
              <p>
                Menu
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('menupageinfo')); ?>" class="nav-link <?php echo e(Request::path() == 'menupageinfo' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Menu Page Info</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('category')); ?>" class="nav-link <?php echo e(Request::path() == 'category' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Category</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('menuitem')); ?>" class="nav-link <?php echo e(Request::path() == 'menuitem' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Our Menu</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview <?php echo e(in_array(Request::path(),array('eventpageinfo','eventinfo'))?'menu-open':''); ?>">
            <a href="#" class="nav-link <?php echo e(in_array(Request::path(),array('eventpageinfo','eventinfo'))?'active':''); ?>">
              <i class="nav-icon fas fa-calendar-alt"></i>
              <p>
                Events
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('eventpageinfo')); ?>" class="nav-link <?php echo e(Request::path() == 'eventpageinfo' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Event Page Info</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('eventinfo')); ?>" class="nav-link <?php echo e(Request::path() == 'eventinfo' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Events</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(url('galleryphoto')); ?>" class="nav-link <?php echo e(Request::path() == 'galleryphoto' ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-images"></i>
              <p>Gallery</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(url('reservationsrequest')); ?>" class="nav-link <?php echo e(Request::path() == 'reservationsrequest' ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-envelope-open"></i>
              <p>Reservation & Contact</p>
            </a>
          </li>  
          <li class="nav-item">
            <a href="<?php echo e(url('contactusrequest')); ?>" class="nav-link <?php echo e(Request::path() == 'contactusrequest' ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-phone-square-alt"></i>
              <p>Contact</p>
            </a>
          </li>
          <li class="nav-item has-treeview <?php echo e(in_array(Request::path(),array('sitesettings','openinghour','sociallinkmgt/create','websitesettings/create'))?'menu-open':''); ?>">
            <a href="#" class="nav-link <?php echo e(in_array(Request::path(),array('sitesettings','openinghour','sociallinkmgt/create','websitesettings/create'))?'active':''); ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Setting
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('sitesettings')); ?>" class="nav-link <?php echo e(Request::path() == 'sitesettings' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Site Setting</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('openinghour')); ?>" class="nav-link <?php echo e(Request::path() == 'openinghour' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Opening Hour</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('sociallinkmgt/create')); ?>" class="nav-link <?php echo e(Request::path() == 'sociallinkmgt/create' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Social Media Link</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('websitesettings/create')); ?>" class="nav-link <?php echo e(Request::path() == 'websitesettings/create' ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Seo Setting</p>
                </a>
              </li>
            </ul>
          </li>

        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->

    
    <div class="side-bar-bottom">
        <ul class="list-unstyled">
          <li class="list-inline-item" data-toggle="tooltip" data-html="true" title="Edit Profile"><a
              href="#"><i class="fas fa-cog"></i></a></li>
          <li class="list-inline-item" data-toggle="tooltip" data-html="true" title="Change Password"><a
              href="#"><i class="fas fa-key"></i></li>
          <li class="list-inline-item" data-toggle="tooltip" data-html="true" title="Lockscreen"><a
              href="#"><i class="fas fa-unlock"></i></a></li>
          <li class="list-inline-item" data-toggle="tooltip" data-html="true" title="Logout">
            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();"><i class="fas fa-power-off"></i>
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
          </li>
        </ul>
      </div><!-- End side-bar-bottom -->
  </aside>

  <style type="text/css">
    .side-bar-bottom {
      width: 100%;
      height: 35px;
      background-color: #343a40;
      position: -webkit-sticky;
      position: sticky;
      bottom: 0px;
      margin-top: 93%;
      color: #cccccc;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
      border-top: 2px solid #444a50;
      padding-top: 25px;
      /*-webkit-box-shadow: 0px 2px 5px 5px black;
      box-shadow: 0px 2px 5px 5px black;*/
  }
  .side-bar-bottom ul li a i{
    color: #fff;
    padding: 10px;
  }
  </style>