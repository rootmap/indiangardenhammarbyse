
<?php $__env->startSection('title','Events'); ?>
<?php $__env->startSection('content'); ?>
<section class="our-story cl-block">
  <div class="container  header-block">
    <div class="row justify-content-center">
      <div class="common_layout_title">
        <h2><?php echo e($EventPageInfo->page_heading); ?></h2>
      </div>
    </div>
  </div>
  <!-- Common Layout Hero -->
  <div class="cl-hero" data-parallax="scroll" style="background-image: url(<?php echo e(URL::asset('upload/eventpageinfo/'.$EventPageInfo->content_background)); ?>);">
    <div class="container">
      <div class="row">
        <div class="col-md-5 col-md-offset-6 block-ded-padd">
          <div class="hero-inner-block">
            <h2><?php echo e($EventPageInfo->content_heading); ?><br><?php echo e($EventPageInfo->content_sub_heading); ?></h2>
            <p>
              <?php echo e($EventPageInfo->content_description); ?>

            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /Common Layout Hero -->

  <!-- Common Layout Body -->
  <div class="cl-body">
    <div class="container">
      <?php if(!empty($EventInfo)): ?>
      <?php 
      $count = 0; 
      
      ?>
      <?php $__currentLoopData = $EventInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      $oe_style = ++$count % 2 ? "odd" : "even"; 

      if($oe_style=='odd'){
      ?>
        <div class="row newhisAr">
          <div class="col-lg-5 col-md-offset-1 nopadd">
            <div class="body-inner-block">
              <h2><?php echo e($evn->heading); ?><br><?php echo e($evn->sub_heading); ?></h2>
            <p class="mb-40">
              <?php echo e($evn->content); ?>

            </p>
              <a href="<?php echo e(url('upload/eventinfo/'.$evn->content_attachment)); ?>" class="btn btn-default btn-inner">Download Floor Plan</a>
            </div>
          </div>
          <div class="col-lg-5  nopadd">
            <figure class="dtrFig">
              <img src="<?php echo e(URL::asset('upload/eventinfo/'.$evn->content_image)); ?>" alt="Venue" class="img-fluid" style="max-height: 453px">
            </figure>
          </div>
        </div>
        <?php 
        }
        else{
          ?>
        <div class="row newhisAr">
         <div class="col-lg-5 col-md-offset-1 nopadd">
            <figure class="dtrFig">
              <img src="<?php echo e(URL::asset('upload/eventinfo/'.$evn->content_image)); ?>" alt="Venue" class="img-fluid" style="max-height: 453px">
            </figure>
          </div>
          <div class="col-lg-5 nopadd">
            <div class="body-inner-block">
              <h2><?php echo e($evn->heading); ?><br><?php echo e($evn->sub_heading); ?></h2>
              <p class="mb-40">
                <?php echo e($evn->content); ?>

              </p>
              <a href="<?php echo e(url('upload/eventinfo/'.$evn->content_attachment)); ?>" class="btn btn-default btn-inner">Download Floor Plan</a>
            </div>
          </div>
        </div>
        <?php
        }
      ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>
  </div>
  <!-- /Common Layout Body -->
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('.newhisAr').each(function(){
            $(this).find('.body-inner-block').css('height',$(this).find('.dtrFig').children('img').height());
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>