<?php $__env->startSection("title","nemm"); ?>
<?php $__env->startSection("content"); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Add New nemm</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('nemm/list')); ?>">nemm Data</a></li>
          <li class="breadcrumb-item active">Create New</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section>
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <!-- left column -->
        <div class="col-md-8 offset-2">
          <!-- general form elements -->
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">nemm</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form action="<?php echo e(url('nemm')); ?>" method="post" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>


              <div class="card-body">

                <div class="form-group">
                  <label for="name">Name:</label>
                  <input type="text" id="name" name="name" class="form-control" placeholder="Please Enter Name">
                </div><!-- end form-group -->
                <div class="form-group">    
                   <label for="name">Select Your Gender:</label>
                  <div class="form-check">

                    <input type="radio" 
                  name="gender" value="Male" class="form-check-input" id="gender_0">
                    <label class="form-check-label" for="gender_0">Male</label>
                  </div>    
                  <div class="form-check">
                    <input type="radio" 
                  name="gender" value="Female" class="form-check-input" id="gender_1">
                    <label class="form-check-label" for="gender_1">Female</label>
                  </div>
                </div>
              </div>
              <!-- /.card-body -->

              <div class="card-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
                <button type="reset" class="btn btn-info">Reset</button>
              </div>
            </form>
          </div>
          <!-- /.card -->

        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </div><!-- /.container-fluid -->
  </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layout.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>