<?php $__env->startSection("title","Producty"); ?>
<?php $__env->startSection("content"); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Add New Producty</h1>
      </div>
      <div class="col-sm-6">

            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('producty/list')); ?>">Producty Data</a></li>
              <li class="breadcrumb-item active">Create New</li>
            </ol>
            <div class="breadcrumb-item">
            <i class="fas fa-angle-right"></i> Edit / Modify 
            </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-8 offset-2">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Producty</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form action="<?php echo e(url('producty/update/'.$dataRow->id)); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          
            <div class="card-body">
                
                        <div class="form-group">
                            <label for="inputGroupSelect07" class="" for="name">Name:</label>
                            <input type="text" 
                             
                        <?php 
                        if(isset($dataRow->name)){
                            ?>
                            value="<?php echo e($dataRow->name); ?>" 
                            <?php 
                        }
                        ?>
                         id="name" name="name" class="form-control" placeholder="Please Enter Name">
                        </div><!-- end form-group -->
                <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="link_file">Link File</label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file"  class="custom-file-input" id="link_file" name="link_file">
                            <input type="hidden" value="<?php echo e($dataRow->link_file); ?>" name="ex_link_file" />
                            <label class="custom-file-label" for="link_file">Choose file</label>
                          </div>
                         

                        </div>
                      </div>
                    </div>
                    <div class="col-md-6 pt-4">
                        <a href="'upload/producty/'.$dataRow->link_file"><i class="fas fa-download"></i> Download File</a>
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
              <button type="submit" class="btn btn-primary">Update</button>
              <button type="reset" class="btn btn-info">Cancel</button>
            </div>
          </form>
        </div>
        <!-- /.card -->

      </div>
      <!--/.col (left) -->
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>