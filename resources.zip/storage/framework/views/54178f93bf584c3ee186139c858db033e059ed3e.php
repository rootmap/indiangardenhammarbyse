<!-- DataTables -->
<script src="<?php echo e(url('admin/plugins/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(url('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(url('admin/dist/js/demo.js')); ?>"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>