
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $__env->yieldContent('title'); ?> | Indian Garden Norrkoping</title>
  <?php echo $__env->yieldContent('css'); ?>
  <?php echo $__env->make('admin.include.headerCss', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldContent('extracss'); ?>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php echo $__env->make('admin.include.top_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('admin.include.main_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <?php echo $__env->yieldContent('content'); ?>
    
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0
    </div>
    <strong>Copyright &copy; 2014-<?php echo e(date('Y')); ?> <a href="http://digimo.se/" target="_blank" >Digimo</a>.</strong> All rights
    reserved.
  </footer>

 
</div>
<!-- ./wrapper -->

<?php echo $__env->make('admin.include.footerJs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('js'); ?>
</body>
</html>
