<?php $__env->startSection("title","pro"); ?>
<?php $__env->startSection("content"); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Add New pro</h1>
      </div>
      <div class="col-sm-6">

            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('pro/list')); ?>">pro Data</a></li>
              <li class="breadcrumb-item active">Create New</li>
            </ol>
            <div class="breadcrumb-item">
            <i class="fas fa-angle-right"></i> Edit / Modify 
            </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-8 offset-2">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">pro</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form action="<?php echo e(url('pro/update/'.$dataRow->id)); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          
            <div class="card-body">
                
                        <div class="form-group">
                            <label for="inputGroupSelect07" class="" for="name">Name:</label>
                            <input type="text" 
                             
                        <?php 
                        if(isset($dataRow->name)){
                            ?>
                            value="<?php echo e($dataRow->name); ?>" 
                            <?php 
                        }
                        ?>
                         id="name" name="name" class="form-control" placeholder="Please Enter Your Name">
                        </div><!-- end form-group -->
                <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="logo">Logo</label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file"  class="custom-file-input" id="logo" name="logo">
                            <input type="hidden" value="<?php echo e($dataRow->logo); ?>" name="ex_logo" />
                            <label class="custom-file-label" for="logo">Choose file</label>
                          </div>
                         

                        </div>
                      </div>
                    </div>
                    <div class="col-md-6 pt-4">
                        <?php if(isset($dataRow->logo)): ?>
                            <?php if(!empty($dataRow->logo)): ?>
                                <img src="<?php echo e(url('upload/pro/'.$dataRow->logo)); ?>" width="150">
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="download_file">Download File</label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file"  class="custom-file-input" id="download_file" name="download_file">
                            <input type="hidden" value="<?php echo e($dataRow->download_file); ?>" name="ex_download_file" />
                            <label class="custom-file-label" for="download_file">Choose file</label>
                          </div>
                         

                        </div>
                      </div>
                    </div>
                    <div class="col-md-6 pt-4">
                        <a href="'upload/pro/'.$dataRow->download_file"><i class="fas fa-download"></i> Download File</a>
                    </div>
                </div><div class="form-group"><label for="gender">    <div class="form-check">
                    <input type="radio"  <?php 
                            if($dataRow->gender=="Male"){
                                ?>
                                checked="checked" 
                                <?php 
                            }
                            ?>
                    name="gender" value="Male" class="form-check-input" id="gender_0">
                    <label class="form-check-label" for="gender_0">Male</label>
                </div>    <div class="form-check">
                    <input type="radio"  <?php 
                            if($dataRow->gender=="Female"){
                                ?>
                                checked="checked" 
                                <?php 
                            }
                            ?>
                    name="gender" value="Female" class="form-check-input" id="gender_1">
                    <label class="form-check-label" for="gender_1">Female</label>
                </div></div>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
              <button type="submit" class="btn btn-primary">Update</button>
              <button type="reset" class="btn btn-info">Cancel</button>
            </div>
          </form>
        </div>
        <!-- /.card -->

      </div>
      <!--/.col (left) -->
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>