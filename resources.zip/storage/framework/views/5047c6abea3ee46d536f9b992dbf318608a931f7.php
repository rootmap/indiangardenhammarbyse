<?php $__env->startSection("title","Edit Our History"); ?>
<?php $__env->startSection("content"); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Our History</h1>
      </div>
      <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('ourhistory/list')); ?>">Datatable </a></li>
              <li class="breadcrumb-item"><a href="<?php echo e(url('ourhistory/create')); ?>">Create New </a></li>
              <li class="breadcrumb-item active">Edit / Modify</li>
            </ol>
      </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make("admin.include.msg", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-8 offset-2">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Edit / Modify Our History</h3>
            <div class="card-tools">
              <ul class="pagination pagination-sm float-right">
                <li class="page-item">
                    <a class="page-link bg-primary" href="<?php echo e(url('ourhistory/create')); ?>"> 
                        Create 
                        <i class="fas fa-plus"></i>
                    </a>
                </li>
                <li class="page-item">
                    <a class="page-link bg-primary" href="<?php echo e(url('ourhistory/list')); ?>"> 
                        Data 
                        <i class="fas fa-table"></i>
                    </a>
                </li>
                <li class="page-item">
                  <a class="page-link  bg-primary" target="_blank" href="<?php echo e(url('ourhistory/export/pdf')); ?>">
                    <i class="fas fa-file-pdf" data-toggle="tooltip" data-html="true"title="Pdf"></i>
                  </a>
                </li>
                <li class="page-item">
                  <a class="page-link  bg-primary" target="_blank" href="<?php echo e(url('ourhistory/export/excel')); ?>">
                    <i class="fas fa-file-excel" data-toggle="tooltip" data-html="true"title="Excel"></i>
                  </a>
                </li>
              </ul>
            </div>
        </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form action="<?php echo e(url('ourhistory/update/'.$dataRow->id)); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          
            <div class="card-body">
                
                <div class="row">
                    <div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label for="heading">Heading</label>
                        <input type="text" 
                            
                        <?php 
                        if(isset($dataRow->heading)){
                            ?>
                            value="<?php echo e($dataRow->heading); ?>" 
                            <?php 
                        }
                        ?>
                        
                        class="form-control" placeholder="Enter Heading" id="heading" name="heading">
                      </div>
                    </div>

                    <div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label for="sub_heading">Sub Heading</label>
                        <input type="text" 
                            
                        <?php 
                        if(isset($dataRow->sub_heading)){
                            ?>
                            value="<?php echo e($dataRow->sub_heading); ?>" 
                            <?php 
                        }
                        ?>
                        
                        class="form-control" placeholder="Enter Sub Heading" id="sub_heading" name="sub_heading">
                      </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Choose Content Image</label>
                            <!-- <label for="customFile">Enter Sub Heading</label> -->
                            <div class="custom-file">
                              <input type="file" class="custom-file-input"  id="content_image" name="content_image">
                              <input type="hidden" value="<?php echo e($dataRow->content_image); ?>" name="ex_content_image" />
                              <label class="custom-file-label" for="customFile">Choose Content Image</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <?php if(isset($dataRow->content_image)): ?>
                            <?php if(!empty($dataRow->content_image)): ?>
                                <img class="img-thumbnail" src="<?php echo e(url('upload/ourhistory/'.$dataRow->content_image)); ?>" width="150">
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                      <!-- text input -->
                      <div class="form-group">
                        <label for="content_detail">Content Detail</label>
                        <textarea class="form-control" rows="3"  placeholder="Enter Detail" id="content_detail" name="content_detail"><?php 
                                if(isset($dataRow->content_detail)){
                                    
                                    echo $dataRow->content_detail;
                                    
                                }
                                ?></textarea>
                      </div>
                    </div>
                </div>
                       
            </div>
            <!-- /.card-body -->

            <div class="card-footer">
              <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> 
                Update
              </button>
              <a class="btn btn-danger" href="<?php echo e(url('ourhistory/edit/'.$dataRow->id)); ?>">
                <i class="far fa-times-circle"></i> 
                Reset
              </a>
            </div>
          </form>
        </div>
        <!-- /.card -->

      </div>
      <!--/.col (left) -->
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>

    <script src="<?php echo e(url('admin/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
    <script>
    $(document).ready(function(){
        bsCustomFileInput.init();
    });
    </script>

<?php $__env->stopSection(); ?>
        
<?php echo $__env->make("admin.layout.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>