<?php $__env->startSection("title","Testtt"); ?>
<?php $__env->startSection("content"); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Add New Testtt</h1>
      </div>
      <div class="col-sm-6">
            <div class="breadcrumb float-sm-right">
                <i class="fas fa-angle-right"></i>  Create New Testtt Data
            </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-8 offset-2">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Testtt</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form action="<?php echo e(url('testtt/update/'.$dataRow->id)); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          
            <div class="card-body">
                
                <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="logo">Logo</label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file"  class="custom-file-input" id="logo" name="logo">
                            <input type="hidden" value="<?php echo e($dataRow->logo); ?>" name="ex_logo" />
                            <label class="custom-file-label" for="logo">Choose file</label>
                          </div>
                         

                        </div>
                      </div>
                    </div>
                    <div class="col-md-6 pt-4">
                        <?php if(isset($dataRow->logo)): ?>
                            <?php if(!empty($dataRow->logo)): ?>
                                <img src="<?php echo e(url('upload/testtt/'.$dataRow->logo)); ?>" width="150">
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="download_files">download files</label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file"  class="custom-file-input" id="download_files" name="download_files">
                            <input type="hidden" value="<?php echo e($dataRow->download_files); ?>" name="ex_download_files" />
                            <label class="custom-file-label" for="download_files">Choose file</label>
                          </div>
                         

                        </div>
                      </div>
                    </div>
                    <div class="col-md-6 pt-4">
                        <a href="'upload/testtt/'.$dataRow->download_files"><i class="fas fa-download"></i> Download File</a>
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
              <button type="submit" class="btn btn-primary">Update</button>
              <button type="reset" class="btn btn-info">Cancel</button>
            </div>
          </form>
        </div>
        <!-- /.card -->

      </div>
      <!--/.col (left) -->
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>