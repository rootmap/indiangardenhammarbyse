<footer class="" style="background: url(<?php echo e(URL::asset('upload/websitesettings/'.$WebsiteSettings->footer_image)); ?>); background-size: cover;">
   <div class="footer-top control-overlay">
    <div class="container">
      <div class="row rellax" data-rellax-speed="0">
        <div class="col-xs-12 col-sm-6 col-md-3">
          <h3 class="footer-title">MY ACCOUNT</h3>
          <ul class="list-unstyled">
            <li><a href="#">My Account</a></li>
            <li><a href="#">Order History</a></li>
            <li><a href="#">Wishlist</a></li>
            <li><a href="#">Newsletter</a></li>
            <li><a href="reservation.html">My Reservation</a></li>
          </ul>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3">
          <h3 class="footer-title">INFORMATION</h3>
          <ul class="list-unstyled">
            <li><a href="about_us.html">About us</a></li>
            <li><a href="#">Delivery Information</a></li>
            <li><a href="contact_us.html">Contact us</a></li>
            <li><a href="#">Terms & Conditions</a></li>
            <li><a href="#">Sitemap</a></li>
          </ul>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3">
          <h3 class="footer-title">opening hour</h3>
          <div class="open-time opening-time">
            <?php if(!empty($OpeningHour)): ?>
            <?php $__currentLoopData = $OpeningHour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php 
              if($opening->day_status=="Closed"){
                $class ='class="clock-time"';
              }
              else{
                $class ='';
              }
            ?>
             <p <?= $class?>>
               <strong><?php echo e($opening->day_name); ?> :</strong> <?php echo e($opening->opening_and_closing_hour); ?>

             </p>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php endif; ?>
         </div>
       </div>
       
       <div class="col-xs-12 col-sm-6 col-md-3">
         <h3 class="footer-title">contacts</h3>
         <div class="address">
           <p class="icon-map"><i class="fa fa-map-marker"></i><strong>address :</strong>  <?php echo e($setting[0]->address); ?> </p>
           
           <p><i class="fa fa-phone"></i><strong>phone :</strong> <a href="tel:<?php echo e($setting[0]->phone); ?>"><?php echo e($setting[0]->phone); ?></a></p>
           <p><i class="fa fa-envelope"></i><strong>email :</strong><a href="mailto:<?php echo e($setting[0]->email_address); ?>"> <?php echo e($setting[0]->email_address); ?></a></p>
         </div>
         <ul class="list-inline footer-social-list">
          <li><a href="<?php echo e($WebsiteSettings->twitter); ?>"><i class="flaticon-twitter1"></i></a></li>
          <li><a href="<?php echo e($WebsiteSettings->facebook); ?>"><i class="flaticon-facebook55"></i></a></li>
          <li><a href="<?php echo e($WebsiteSettings->linkin); ?>"><i class="flaticon-linkedin11"></i></a></li>
          <li><a href="<?php echo e($WebsiteSettings->google_plus); ?>"><i class="flaticon-google116"></i></a></li>
          <li><a href="<?php echo e($WebsiteSettings->pinterest); ?>"><i class="flaticon-pinterest34"></i></a></li>
        </ul>
      </div>

      
    </div>
  </div>
</div>
<div class="footer-bottom">
  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <div class="copy-right pull-left">
          <p>Copyright-<?php echo e(date('Y')); ?> Indian graden</p>
        </div>
        
        <div class="back-top pull-right">
          <i class="fa <?php echo e($WebsiteSettings->bottom_icon); ?> "></i>
        </div>
      </div>
    </div>
  </div>
</div>
</footer>