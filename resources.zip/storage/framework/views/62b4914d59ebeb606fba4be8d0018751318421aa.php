<?php $__env->startSection('title','Menu'); ?>
<?php $__env->startSection('js'); ?>
  <script type="text/javascript">
    
  </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  
<!--===| Menu Page Top Banner Start |menu-banner===-->
  <section style="background-image: url(<?php echo e(URL::asset('upload/menupageinfo/'.$MenuPageInfo[0]->header_image)); ?>);">
    <div class="banner-wrapper control-overlay">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 menu">
            <h1><?php echo e($MenuPageInfo[0]->heading); ?></h1>
            <p><?php echo e($MenuPageInfo[0]->sub_heading); ?></p>
          </div>
        </div>
      </div>
    </div>
  </section>
<!--===| Menu Page Top Banner End |===-->

<!--===| Menu Page First Block Start |===-->
<section class="menus">
  <div class="container">
    <div class="gallery-trigger text-center">
      <ul id="filter">
         <li><a class="active catloadpro" href="javascript:void(0);" data-group="total" >all</a></li> 
         <?php if(count($category)>0): ?>
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a href="javascript:void(0);" class="catloadpro" data-group="<?php echo e(str_replace(' ','_',strtolower($c->name))); ?>"><?php echo e($c->name); ?></a></li> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
      </ul> 
    </div>
    <?php if(!empty($MenuItem)): ?>
    <?php $__currentLoopData = $MenuItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row mb-40 total <?php echo e(str_replace(' ','_',strtolower($ca['name']))); ?>">
      <div class="col-xs-12">
        
        <div class="top-icon text-center">
          <!-- <img src="<?php echo e(url('site/img/custom/menu/pesto_goat_cheese_sun_dried_tomato_polenta.jpg')); ?>" alt="Appetizer"> -->
        <h1><?php echo e($ca['name']); ?></h1>
        <p><?php echo e($ca['description']); ?></p>
        </div>
        
      </div>
      <div class="clearfix"></div><br><br>
      <?php $i = 1; ?>
      <?php $__currentLoopData = $ca['scat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
      <div class="col-md-3 mb-1">
        <div class="menus-block">
          <?php
            if($sca['special']=='Yes'){
              $class = 'class="starred"';
              $img ='';
            }
            //site/img/chili.png
            elseif ($sca['spicy']=='Yes') {
              $class = 'class="starreds"';
              $img = "<img src='".URL::asset('site/img/chili.png')."'>";
              //echo $img;
            }
          ?>
          <figure <?= $class ?>>
            <img style="height:230px;" src="<?php echo e(URL::asset('upload/menuitem/'.$sca['menu_item_image'])); ?>" alt="<?php echo e($sca['name']); ?>">
          </figure>
          <div class="inner-text">
            <h4><?php echo e($sca['name']); ?></h4>
            <p class="sub-title"><?php echo e($sca['description']); ?></p>
              
              <p class="ingradients1">Price : <?php echo e($sca['price']); ?> kr <?= $img ?></p>
          </div>
        </div>
      </div>


      
      <?php  $i++; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
  </div>
</section>
<!--===| Menu Page First Block End |===-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>