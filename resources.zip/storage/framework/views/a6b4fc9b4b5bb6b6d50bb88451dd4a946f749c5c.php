<?php $__env->startSection("title","Active2"); ?>
<?php $__env->startSection("content"); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Add New Active2</h1>
      </div>
      <div class="col-sm-6">

            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('active2/list')); ?>">Active2 Data</a></li>
              <li class="breadcrumb-item active">Create New</li>
            </ol>
            <div class="breadcrumb-item">
            <i class="fas fa-angle-right"></i> Edit / Modify 
            </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-8 offset-2">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Active2</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form action="<?php echo e(url('active2/update/'.$dataRow->id)); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          
            <div class="card-body">
                
                    <div class="form-check">
                    <input type="checkbox" disabled="disabled"  for="name" class="form-check-input" value="Enter Name" />
                        <input type="checkbox" class="form-check-input" id="exampleCheck1" for="name" value="Enter Name">
                        <label class="form-check-label" for="
                                        &nbsp;<input type="checkbox"  id="name_0" name="name" value="Active">&nbsp;Active  &nbsp; 
                                    
                                        &nbsp;<input type="checkbox"  id="name_1" name="name" value="Inactive">&nbsp;Inactive  &nbsp; 
                                    ">
                                        &nbsp;<input type="checkbox"  id="name_0" name="name" value="Active">&nbsp;Active  &nbsp; 
                                    
                                        &nbsp;<input type="checkbox"  id="name_1" name="name" value="Inactive">&nbsp;Inactive  &nbsp; 
                                    </label>
                    </div>
                    
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
              <button type="submit" class="btn btn-primary">Update</button>
              <button type="reset" class="btn btn-info">Cancel</button>
            </div>
          </form>
        </div>
        <!-- /.card -->

      </div>
      <!--/.col (left) -->
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>