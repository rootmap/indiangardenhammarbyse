
<?php $__env->startSection('title','Reservation'); ?>
<?php $__env->startSection('content'); ?>
<section class="events cl-block">
    <div class="container  header-block">
      <div class="row justify-content-center">
        <div class="common_layout_title">
          <h2>CONTACT US</h2>
        </div>
      </div>
    </div>
    <!-- Common Layout Hero -->
    <div class="cl-hero" data-parallax="scroll" style="background-image: url(<?php echo e(url('site/img/custom/event-hero.jpg')); ?>);">
    <div class="container">
      <div class="row">

        <?php if(\Session::has('success')): ?>
        <script type="text/javascript">
          Swal.fire({
            position: 'top-center',
            icon: 'success',
            title: 'Your message has been sent successfully',
            showConfirmButton: false,
            timer: 2000
          })
        </script>
          
      <?php endif; ?>
        <div class="col-md-5 col-md-offset-6">
          <div class="hero-inner-block" style="padding: 35px 60px;">
              <h2>Book A Table</h2>
              <form action="<?php echo e(url('reservation/request')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <input id="name" name="name" class="form-control form-control-lg" type="text" placeholder="Enter your name">
                </div>
                <div class="form-group">
                  <input id="email" name="email" class="form-control form-control-lg" type="email" placeholder="Enter your email address">
                </div>
                <div class="form-group">
                  <input id="datepicker" class="form-control form-control-lg" name="reservations_date" type="text" placeholder="Select Date">
                </div>
                <div class="form-group">
                  <select name="reservations_time" class="form-control form-control-lg">
                    <option value="">Select Time</option>
                    <?php for($i=0; $i<=23; $i++): ?>
                        <option value="<?php echo e(strlen($i)==1?'0'.$i:$i); ?>:00"><?php echo e(strlen($i)==1?'0'.$i:$i); ?>:00</option>
                        <option value="<?php echo e(strlen($i)==1?'0'.$i:$i); ?>:15"><?php echo e(strlen($i)==1?'0'.$i:$i); ?>:15</option>
                        <option value="<?php echo e(strlen($i)==1?'0'.$i:$i); ?>:30"><?php echo e(strlen($i)==1?'0'.$i:$i); ?>:30</option>
                        <option value="<?php echo e(strlen($i)==1?'0'.$i:$i); ?>:45"><?php echo e(strlen($i)==1?'0'.$i:$i); ?>:45</option>
                    <?php endfor; ?>
                  </select>
                </div>
                <input type="hidden" name="reservations_status" value="Pending">
                <div class="form-group">
                  <select name="person" class="form-control form-control-lg">
                    <option value="">Select person</option>
                    <option value="1 person">1 person</option>
                    <option value="2 person">2 person</option>
                    <option value="3 person">3 person</option>
                    <option value="4 person">4 person</option>
                    <option value="5 person">5 person</option>
                    <option value="6 person">6 person</option>
                  </select>
                </div>
                <div class="form-group">
                  <button class="btn btn-block btn-form">Book a table now</button>
                </div>
              </form>
            </div>
        </div>
      </div>
    </div>
  </div>
    <!-- /Common Layout Hero -->
  </section>
<section class="section-padding contact-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-6">
        <div class="form-wrapper">
        <h2>CONTACT US</h2>
        
        <form id='contact_form' name="enqueryForm" method="post" action="<?php echo e(url('contact/request')); ?>">
          <?php echo e(csrf_field()); ?>

            <div class="row">
              <div class="col-xs-12 col-sm-12">
                <input type="text" class="form-control" name="name" placeholder="name">
              </div>
              
              <div class="col-xs-12 col-sm-12">
                <input id="email" type="email" class="form-control" name="email" placeholder="e-mail">
              </div>
              <div class="col-xs-12 col-sm-12">
                <input type="text" class="form-control" name="subject" placeholder="subject">
              </div>
              <div class="col-xs-12 col-sm-12">
                <textarea id="message" class="form-control" rows="4" name="message" placeholder="message"></textarea>
              </div>
              
              <div class="col-xs-12 col-sm-12">
                <button class="btn" name="submit" type="submit">submit message</button>
                <input type="hidden" value="Unseen" name="contact_status" />
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="col-xs-12 col-sm-6">
        <iframe
            src="<?php echo e($setting[0]->contact_map_source_url); ?>"
            width="100%" height="470" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
      </div>
    </div>
        <div class="address-wrapper">
          <div class="row">
            <div class="col-xs-12 col-sm-4">
              <div class="left">
                <h3>location</h3>
                <p><?php echo e($setting[0]->address); ?></p>
              </div>
            </div>
            <div class="col-xs-12 col-sm-4">
              <div class="middle">
                <h3>table booking</h3>
                <p><a href="tel:<?php echo e($setting[0]->phone); ?>"><?php echo e($setting[0]->phone); ?></a><br>
                  <a href="mailto:<?php echo e($setting[0]->email_address); ?>"><?php echo e($setting[0]->email_address); ?></a></p>  
              </div>
            </div>
            <div class="col-xs-12 col-sm-4">
              <div class="right">
                <h3>get directions</h3>
                <p>From Airport 3 Minutes Taxi Distance
                From Bus Stop 10 Minutes Walking Distance</p>  
              </div>
            </div>
          </div>
        </div>
      </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>