<div class="popup-section"  id="resetArea" style="background-color: rgb(255,255,255,0.95); position: fixed;">
    <div class="row">
      <div class="col-md-12">
        <a href="javascript:void(0);"  
        class="cross"
        style="font-size: 50px; text-align: right; padding-right: 20px; padding-top: 20px; text-decoration: none; color: #a87f41; display: block; right:30px; top:10px; cursor: pointer;">&times;</a>
        <div class="col-md-6 col-md-offset-3" id="logsignupreg" style="padding-top:5%;">
            <div class="col-md-12 mb-1" style="font-family: Arial,Helvetica,sans-serif; color: #a87f41; text-align: center; font-weight: bolder; font-size: 60px; text-transform: uppercase; display: block; height:40px;">Reset</div>

            <div class="col-md-8 mb-1 col-md-offset-2">
                <div class="col-md-12">
                     <p class="text-divider"><span>Please Enter Email</span></p>
                </div>
            </div>

            <div class="col-md-8  col-md-offset-2">
                <div class="col-md-12">
                     <div class="form-group">
                      <label style="font-weight: 600;">Email Address</label>
                      <input style="border-radius: 0px;" id="email_login" name="email_login" class="form-control form-control-lg" type="text" placeholder="Enter Email Address">
                    </div>
                </div>
            </div>

            <div class="col-md-8 mb-1 col-md-offset-2">
                <div class="col-md-12">
                     <button class="btn btn-info" type="button">
                        <i class="fa fa-unlock" aria-hidden="true"></i> Reset 
                      </button>
                </div>
            </div>
            

        </div>
      </div>
    </div>
</div>