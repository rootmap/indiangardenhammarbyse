
<?php $__env->startSection('title','Our Story'); ?>
<?php $__env->startSection('content'); ?>
<section class="our-story cl-block">
  <div class="container  header-block">
    <div class="row justify-content-center">
      <div class="common_layout_title">
        <h2><?php echo e($history[0]->page_heading); ?></h2>
      </div>
    </div>
  </div>
  <!-- Common Layout Hero -->
  <div class="cl-hero" data-parallax="scroll" style="background-image: url(<?php echo e(URL::asset('upload/ourhistorypageinfo/'.$history[0]->background_image)); ?>);">
    <div class="container">
      <div class="row">
        <div class="col-md-5 col-md-offset-6 block-ded-padd">
          <div class="hero-inner-block">
            <h2><?= html_entity_decode($history[0]->content_heading)?></h2>
            <p>
              <?php echo e($history[0]->content_description); ?>

            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /Common Layout Hero -->

  <!-- Common Layout Body -->
  <div class="cl-body">
    <div class="container">
      <?php if(!empty($OurHistory)): ?>
      <?php 
      $count = 0; 
      
      ?>
      <?php $__currentLoopData = $OurHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $his): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      $oe_style = ++$count % 2 ? "odd" : "even"; 

      if($oe_style=='odd'){
      ?>
      <div class="row newhisAr">
        <div class="col-lg-5 col-lg-offset-1 nopadd">
          <figure class="dtrFig">
            <img src="<?php echo e(URL::asset('upload/ourhistory/'.$his->content_image)); ?>" alt="<?php echo e($his->heading); ?>" class="img-fit">
          </figure>
        </div>
        <div class="col-lg-5  nopadd">
          <div class="body-inner-block">
            <h2><?php echo e($his->heading); ?><br><?php echo e($his->sub_heading); ?></h2>
            <p class="mb-40">
              <?php echo e($his->content_detail); ?>

            </p>
          </div>
        </div>
      </div>
      <?php 
      }
      else
      {
      ?>
          <div class="row newhisAr">
            <div class="col-lg-5 col-lg-offset-1 nopadd">
              <div class="body-inner-block">
                <h2><?php echo e($his->heading); ?><br><?php echo e($his->sub_heading); ?></h2>
            <p class="mb-40">
              <?php echo e($his->content_detail); ?>

            </p>
              </div>
            </div>
            <div class="col-lg-5 nopadd">
              <figure class="dtrFig">
                <img src="<?php echo e(URL::asset('upload/ourhistory/'.$his->content_image)); ?>" alt="<?php echo e($his->heading); ?>" class="img-fit">
              </figure>
            </div>
          </div>
      <?php
        }
      ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      
    </div>
  </div>
  <!-- /Common Layout Body -->
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('.newhisAr').each(function(){
            $(this).find('.body-inner-block').css('height',$(this).find('.dtrFig').children('img').height());
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>