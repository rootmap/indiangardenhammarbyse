<?php $__env->startSection("title","Noman"); ?>
<?php $__env->startSection("content"); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Add New Noman</h1>
      </div>
      <div class="col-sm-6">

            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('noman/list')); ?>">Noman Data</a></li>
              <li class="breadcrumb-item active">Create New</li>
            </ol>
            <div class="breadcrumb-item">
            <i class="fas fa-angle-right"></i> Edit / Modify 
            </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-8 offset-2">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Noman</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form action="<?php echo e(url('noman/update/'.$dataRow->id)); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          
            <div class="card-body">
                
                <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="downlo">Downlo</label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file"  class="custom-file-input" id="downlo" name="downlo">
                            <input type="hidden" value="<?php echo e($dataRow->downlo); ?>" name="ex_downlo" />
                            <label class="custom-file-label" for="downlo">Choose file</label>
                          </div>
                         

                        </div>
                      </div>
                    </div>
                    <div class="col-md-6 pt-4">
                        <a href="<?php echo e(url('upload/noman/'.$dataRow->downlo)); ?>"><i class="fas fa-download"></i> Download File</a>
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
              <button type="submit" class="btn btn-primary">Update</button>
              <button type="reset" class="btn btn-info">Cancel</button>
            </div>
          </form>
        </div>
        <!-- /.card -->

      </div>
      <!--/.col (left) -->
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>