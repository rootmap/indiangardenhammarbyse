<?php $__env->startSection("title","Create New Event Page Info"); ?>
<?php $__env->startSection("content"); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Event Page Info</h1>
      </div>
      <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item active">Create New Event Page Info</li>
            </ol>
      </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make("admin.include.msg", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-8 offset-2">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Create New Event Page Info</h3>            
        </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form action="<?php echo e(url('eventpageinfo')); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          
            <div class="card-body">
                
                <div class="row">
                    <div class="col-sm-12">
                      <!-- text input -->
                      <div class="form-group">
                        <label for="page_heading">Page Heading</label>
                        <input type="text" class="form-control" placeholder="Enter Page Heading" id="page_heading" name="page_heading">
                      </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label for="content_heading">Content Heading</label>
                        <input type="text" class="form-control" placeholder="Enter Content Heading" id="content_heading" name="content_heading">
                      </div>
                    </div>

                    <div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label for="content_sub_heading">Content Sub Heading</label>
                        <input type="text" class="form-control" placeholder="Enter Content Sub Heading" id="content_sub_heading" name="content_sub_heading">
                      </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-sm-12">
                      <!-- text input -->
                      <div class="form-group">
                        <label for="content_description">Content Description</label>
                        <textarea class="form-control" rows="3"  placeholder="Enter Content Description" id="content_description" name="content_description"></textarea>
                      </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Choose Content Background</label>
                            <!-- <label for="customFile">Choose Content Background</label> -->

                            <div class="custom-file">
                              <input type="file" class="custom-file-input"  id="content_background" name="content_background">
                              <label class="custom-file-label" for="customFile">Choose Content Background</label>
                            </div>
                        </div>
                    </div>
                </div>
        <div class="row">
            <div class="col-sm-12">
              <!-- radio -->
              <div class="form-group">
              <label>Choose Module Status</label>
        
                        <div class="form-check">
                            <input class="form-check-input" type="radio" 
                          id="module_status_0" name="module_status" value="Active">
                          <label class="form-check-label">Active</label>
                        </div>
                
                        <div class="form-check">
                            <input class="form-check-input" type="radio" 
                          id="module_status_1" name="module_status" value="Inactive">
                          <label class="form-check-label">Inactive</label>
                        </div>
                
                    </div>
                </div>
            </div>
                   
            </div>
            <!-- /.card-body -->

            <div class="card-footer">
              <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Submit</button>
              <a class="btn btn-danger" href="<?php echo e(url('eventpageinfo/create')); ?>"><i class="far fa-times-circle"></i> Reset</a>
            </div>
          </form>
        </div>
        <!-- /.card -->

      </div>
      <!--/.col (left) -->
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>

    <script src="<?php echo e(url('admin/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
    <script>
    $(document).ready(function(){
        bsCustomFileInput.init();
    });
    </script>

<?php $__env->stopSection(); ?>
        
<?php echo $__env->make("admin.layout.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>