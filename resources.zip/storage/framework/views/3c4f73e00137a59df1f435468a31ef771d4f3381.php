<?php $__env->startSection("title","Test Four"); ?>
<?php $__env->startSection("content"); ?>
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1>Test Four</h1>
              </div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('testfour/create')); ?>">Create New </a></li>
                  <li class="breadcrumb-item active">Test Four Data</li>
                </ol>
              </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make("admin.include.msg", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
          </div><!-- /.container-fluid -->
        </section>
        
        <section class="content">
          <div class="row">
            <div class="col-12">
              <!-- /.card -->
              <div class="card">

                <div class="card-header">
                  <h3 class="card-title">Test Four Data</h3>

                    <div class="card-tools">
                      <ul class="pagination pagination-sm float-right">
                        <li class="page-item">
                            <a class="page-link bg-primary" href="<?php echo e(url('testfour/create')); ?>"> 
                                Add New 
                                <i class="fas fa-plus"></i> 
                            </a>
                        </li>
                        <li class="page-item">
                          <a class="page-link" target="_blank" href="<?php echo e(url('testfour/export/pdf')); ?>">
                            <i class="fas fa-file-pdf" data-toggle="tooltip" data-html="true"title="Pdf"></i>
                          </a>
                        </li>
                        <li class="page-item">
                          <a class="page-link" target="_blank" href="<?php echo e(url('testfour/export/excel')); ?>">
                            <i class="fas fa-file-excel" data-toggle="tooltip" data-html="true"title="Excel"></i>
                          </a>
                        </li>
                      </ul>
                    </div>
                </div>


                
                <!-- /.card-header -->
                <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th class="text-center">ID</th>
                            <th class="text-center">Category</th>
                            <th class="text-center">Logo</th>
                            <th class="text-center">Donwload Files</th>
                            <th class="text-center">Created At</th>
                            <th class="text-center">Actions</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($dataRow)): ?>
                            <?php $__currentLoopData = $dataRow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                <tr>
                                    <td class="text-center"><?php echo e($row->id); ?></td><td class="text-center"><?php echo e($row->category); ?></td><td class="text-center"><?php echo e($row->logo); ?></td><td class="text-center"><?php echo e($row->donwload_files); ?></td>
                                    <td><?php echo e(formatDate($row->created_at)); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(url('testfour/edit/'.$row->id)); ?>" type="button" class="btn btn-default">
                                                Edit 
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?php echo e(url('testfour/delete/'.$row->id)); ?>" type="button" class="btn btn-default">
                                                Delete 
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </div>
                                    </td>
                                
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                                        
                    </tbody>
                    <tfoot>
                    <tr>
                        <th class="text-center">ID</th>
                        <th class="text-center">Category</th>
                        <th class="text-center">Logo</th>
                        <th class="text-center">Donwload Files</th>
                        <th class="text-center">Created At</th>
                        <th class="text-center">Actions</th>

                    </tr>
                    </tfoot>
                  </table>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("css"); ?>
    <?php echo $__env->make("admin.include.lib.datatable.css", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
    <?php echo $__env->make("admin.include.lib.datatable.js", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
        
<?php echo $__env->make("admin.layout.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>