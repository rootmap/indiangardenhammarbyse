<!DOCTYPE HTML>
<html lang="en" class="no-js">
   <head>
      <!-- Basic -->
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
      
      <title><?php echo $__env->yieldContent('title'); ?> | Indian Gadren</title>
      <?php echo $__env->make('site.include.headerCss', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->yieldContent('css'); ?>
      <style type="text/css">
       .control-overlay {
           background: 0% 0% / cover rgba(0,0,0, 0.5);
       }
     </style>

   </head>
   <body onload="initialize()">
      <div class="loader"></div>
      <!--===| Search Start |===-->
      <?php echo $__env->make('site.include.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--===| Search End |===-->
      <!--===| Pop Up Google Map Start |===-->
      <?php echo $__env->make('site.include.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('site.include.signup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('site.include.reset', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--===| Pop Up Google Map End |===-->
      <!--===| Header Top Start |===-->
      <div id="offcanvas-container" class="wrapper offcanvas-container">
         <div class="inner-wrapper offcanvas-pusher">
            <?php echo $__env->make('site.include.header-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!--===| Header Top End |===-->
            <?php echo $__env->make('site.include.logo-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /header-wrapper -->    
             <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('site.include.reservation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!--====| Footer section Start|====-->
            <?php echo $__env->make('site.include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!--==| Footer section End|==-->
         </div>
         <!--==| .inner-wrapper |==-->
         <?php echo $__env->make('site.include.mobile_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <!-- .wrapper -->
      <?php echo $__env->make('site.include.footerJs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      <!-- <script src="<?php echo e(url('parallax/parallax.js')); ?>"></script>
      <script src="https://cdn.jsdelivr.net/npm/simple-parallax-js@5.2.0/dist/simpleParallax.min.js"></script> -->
      <script src="<?php echo e(url('rellax/rellax.min.js')); ?>"></script>
      <script src="http://a.vimeocdn.com/js/froogaloop2.min.js"></script>
      <script>
        // Accepts any class name
        var rellax = new Rellax('.rellax');
      </script>
      <?php echo $__env->yieldContent('js'); ?>
      <script type="text/javascript">



          $(document).ready(function(){


            $("#playVidemomo").css("height",$('#ifvemo').height());
            $("#playVidemomo").css("margin-top",-$('#ifvemo').height());
            $("#playVidemomo").css("width",$('#ifvemo').width());
              

             $("#loadvideos").click(function(){
                $("#videos").css("padding-top","149px");
                $('html, body').animate({
                    scrollTop: $("#videos").offset().top
                }, 1000);
             });

             $("#playVidemomo").click(function(){
                $("#playVidemomo").hide();

              var iframe = $('#ifvemo')[0];

              

              var player = $f(iframe);

              //$('#stop').click(function() {
                //  alert('stoped');
               //   player.api('pause');
              //});


              //$('#play').click(function(){
                  //alert('play');
                  player.api('play');
              //})
             });

             $('.hero').css('padding-top','3em');


             var sliderShowArea=$(window).height()-102;
             $('#slider-container-area').css('height',sliderShowArea);

             if(sliderShowArea>=1000)
               {
                  $('#buttonRea').css('padding-top','10em');
                  $('#logoarearea').css('padding-top','6em');
               } 
               else if(sliderShowArea>=900)
               {
                  $('#buttonRea').css('padding-top','9.5em');
                  $('#logoarearea').css('padding-top','5em');
               }
               else if(sliderShowArea>=800)
               {
                  $('#buttonRea').css('padding-top','8em');
                  $('#logoarearea').css('padding-top','4em');
               }
               else if(sliderShowArea>=700)
               {
                  $('#buttonRea').css('padding-top','7em');
                  $('#logoarearea').css('padding-top','3.5em');
               }
               else if(sliderShowArea>=600)
               {
                  $('#buttonRea').css('padding-top','6em');
                  $('#logoarearea').css('padding-top','3em');
               }
               else if(sliderShowArea>=500)
               {
                  $('#buttonRea').css('padding-top','3em');
                  $('#logoarearea').css('padding-top','1.5em');
               }
               else
               {
                  $('#buttonRea').css('padding-top','3em');
                  $('#logoarearea').css('padding-top','1.5em');
               }
             

             $(document).scroll(function(){
                console.log($(window).height());
             });

             $( window ).resize(function() {
                var sliderShowArea=$(window).height()-102;
                $('#slider-container-area').css('height',sliderShowArea);
                console.log($(window).height()-102);

               if(sliderShowArea>=1000)
               {
                  $('#buttonRea').css('padding-top','10em');
                  $('#logoarearea').css('padding-top','6em');
                  
               } 
               else if(sliderShowArea>=900)
               {
                  $('#buttonRea').css('padding-top','9.5em');
                  $('#logoarearea').css('padding-top','5em');
               }
               else if(sliderShowArea>=800)
               {
                  $('#buttonRea').css('padding-top','8em');
                  $('#logoarearea').css('padding-top','4em');
               }
               else if(sliderShowArea>=700)
               {
                  $('#buttonRea').css('padding-top','7em');
                  $('#logoarearea').css('padding-top','3.5em');
               }
               else if(sliderShowArea>=600)
               {
                  $('#buttonRea').css('padding-top','6em');
                  $('#logoarearea').css('padding-top','3em');
               }
               else if(sliderShowArea>=500)
               {
                  $('#buttonRea').css('padding-top','3em');
                  $('#logoarearea').css('padding-top','1.5em');
               }
               else
               {
                  $('#buttonRea').css('padding-top','3em');
                  $('#logoarearea').css('padding-top','1.5em');
               }


            });

             $("#loginsubmit").click(function(){

                  var email_login=$("input[name=email_login]").val();
                  var password_login=$("input[name=password_login]").val();

                  if(email_login.length==0)
                  {
                      swal({
                        title: "Warning",
                        text: "Email address required!",
                        icon: "error",
                        button: "Ok",
                      });

                      return false;
                  }

                  if(password_login.length==0)
                  {
                      swal({
                        title: "Warning",
                        text: "Password required!",
                        icon: "error",
                        button: "Ok",
                      });

                      return false;
                  }

                  $(this).html('<i class="fa fa-unlock" aria-hidden="true"></i> Login <i class="fa fa-spinner fa-spin" aria-hidden="true"></i>');

                  var logincustomer="<?php echo e(url('customer/login')); ?>";

                  $.ajax({
                      'async': false,
                      'type': "POST",
                      'global': false,
                      'dataType': 'json',
                      'url': logincustomer,
                      'data':{'email':email_login,'password':password_login,'_token':'<?php echo e(csrf_token()); ?>'},
                      'success': function (data) {
                          $("#cartMessageProShow").html(successMessage("Product Added To Cart Successfully.")); 
                      }
                  });


                  return false;
              });
          });

          var isMobile = {
              Android: function() {
                  return navigator.userAgent.match(/Android/i);
              },
              BlackBerry: function() {
                  return navigator.userAgent.match(/BlackBerry/i);
              },
              iOS: function() {
                  return navigator.userAgent.match(/iPhone|iPad|iPod/i);
              },
              Opera: function() {
                  return navigator.userAgent.match(/Opera Mini/i);
              },
              Windows: function() {
                  return navigator.userAgent.match(/IEMobile/i) || navigator.userAgent.match(/WPDesktop/i);
              },
              any: function() {
                  return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
              }
          };

          if( isMobile.any() )
          { 
            $("#logsignup").attr("style","padding-top:0px;"); 
            $(".font-5-slider").attr("style","position: absolute; left: 0px; right: 0px; font-size:17px;"); 
            
            $("#mobnavData").removeClass("pull-right"); 
            $("#mobnavData").addClass("pull-left"); 
          }
          else
          { 
            $("#logsignup").attr("style","padding-top:7%;");
            $(".font-5-slider").attr("style","position: absolute; left: 0px; right: 0px; font-size:48px;");  
            $("#mobnavData").addClass("pull-right"); 
            $("#mobnavData").removeClass("pull-left"); 
          }

          $("#logsignupexit").click(function(){
              $("#loginArea").fadeOut('slow');
          });


      </script>
      <!--Start of Tawk.to Script-->
      <script type="text/javascript">
      $(document).ready(function(){

          //$(".typewriter").hide().show("slide", { direction: "left" }, 1500);


          var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
          (function(){
          var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
          s1.async=true;
          s1.src='https://embed.tawk.to/5e4f9c25298c395d1ce90fdd/default';
          s1.charset='UTF-8';
          s1.setAttribute('crossorigin','*');
          s0.parentNode.insertBefore(s1,s0);
          })();

 /*         .theme-background-color {
    background-color: #03a84e;
}*/

      });
      
      </script>
      <!--End of Tawk.to Script-->
   </body>
</html>