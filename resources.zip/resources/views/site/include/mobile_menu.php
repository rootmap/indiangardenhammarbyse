<!--==| offcanvas-menu |==-->
<div class="offcanvas-menu offcanvas-effect  hidden-sm hidden-md hidden-lg">
  <button id="off-canvas-close-btn" class="close" type="button" aria-hidden="true" data-toggle="offcanvas" >&times;</button>
  <h2>Sidebar Menu</h2>
  <ul>
    <li><a href="index.php">Home</a></li>
     <li ><a href="our-story.php">Our History</a></li>
     <li ><a href="menu.php">Menu</a></li>
     <li><a href="events.php">Events </a></li>
     <li><a href="gallery.php">Gallery </a></li>
     <li><a href="reservation.php">Reservation & Contact</a></li>
  </ul>
</div><!-- .offcanvas-menu -->
</div><!-- .wrapper -->