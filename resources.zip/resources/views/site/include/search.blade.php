<div class="search-wrapper">
 <div class="search-container">
    <div class="search-contents">
       <p class="close"><i class="fa fa-times"></i></p>
       <form>
          <input type="search" placeholder="type keyword(s) here">
          <button class="btn btn-primary btn-lg" type="submit">Search</button>
       </form>
    </div>
 </div>
</div>
