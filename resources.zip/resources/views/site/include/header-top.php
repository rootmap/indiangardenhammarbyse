<div class="header-top">
   <div class="container">
      <div class="row">
         <div class="col-xs-12 hidden-xs col-sm-6">
            <!-- Top right side content -->
            <ul class="fa-ul list-inline top-info level-one">
               <!-- <li><a href="#"><i class="flaticon-facebook55"></i></a></li>
                  <li><a href="#"><i class="flaticon-twitter1"></i></a></li>
                  <li><a href="#"><i class="flaticon-socialnetwork171"></i></a></li> -->
               <li><i class="fa fa-phone"></i> <a class="tel-no" href="tel:564351423">079056786</a></li>
               <!-- <li><i class="fa fa-envelope"></i><a class="tel-no" href="mailto:support@digimo.com" > support@digimo.com</a></li> -->
            </ul>
         </div>
         <!-- Top right side content -->
         <div class="col-xs-12 col-sm-6">
            <ul class="list-inline top-social level-one pull-right">
               <li><a href="https://www.facebook.com/indiangardennorrkoping"><i class="fa fa-facebook"></i></a></li>
               <li><a href="https://www.instagram.com/indiangarden.nu/"><i class="fa fa-instagram"></i></a></li>
               <!-- <li><a href="#"><i class="fa fa-tripadvisor"></i></a></li> -->
               <li id="map" class="location"><i class="fa fa-user"></i> Login</li>
               <li class="flag-area">
                  <dl id="sample" class="dropdown">
                     <dt><a href="#"><span><img class="flag" src="img/usa-flag.png" alt="English" /></span></a></dt>
                     <dd>
                        <ul class="flags-align">
                           <li><a href="#"><img class="flag" src="img/Sweden-Flag.png" alt="Swedish" /></a></li>
                           <li><a href="#"><span><img class="flag" src="img/usa-flag.png" alt="English" /></span></a></li>
                        </ul>
                     </dd>
                  </dl>
               </li>
            </ul>
            <!-- <div class="clearfix"></div> -->
            <ul class="fa-ul list-inline top-info level-one pull-right">
               <!-- <li><a href="https://www.facebook.com/indiangardennorrkoping"><i class="flaticon-facebook55"></i></a></li>
               <li style="margin-right: 10px"><a href="https://www.instagram.com/indiangarden.nu/"><i class="fa fa-instagram"></i></a></li>
               <li style="margin-right: 10px"><a href="#"><i class="flaticon-socialnetwork171"></i></a></li> -->
            </ul>
         </div>
      </div>
   </div>
</div>