<div class="popup-section">
 <div class="container">
    <div class="row">
       <div class="col-xs-12 col-sm-10 col-sm-offset-1">
          <div class="popup-wrapper">
             <div class="row">
                <div class="cross">
                   <p>X</p>
                </div>
                <!-- <div class="col-xs-12 col-sm-6">
                   <div class="container">
                      <P class="heading-top">Login with Social Media</P>
                      <p class="heading">address</p>
                      <p>228 Park Ave S,
                         <br>New York, NY 10003, USA
                      </p>
                      <p class="heading">Email</p>
                      <p>please feel free to send us an email</p>
                      <p><strong>email:</strong><a href="mailto:info@digimo.com">info@digimo.com</a></p>
                      <p class="heading">contact no</p>
                      <p>give us a call</p>
                      <p><strong>phone:</strong><a href="tel:14535621224">1-453-562-1224</a></p>
                      <p><strong>mobile:</strong><a href="tel:12329451264">1-232-945-1264</a></p>
                   </div>
                </div>
                <div class="col-xs-12 col-sm-6">
                   <P class="heading-top">Login with Email</P>
                   <input type="text" placeholder="Enter Email Address">
                   <input type="text" placeholder="Enter Password">
                   <button></button>
                </div> -->
                
                
                <form action="/action_page.php">
                  <div class="row">
                    <h2 style="text-align:center">Login with Social Media or Manually</h2>
                    <div class="vl">
                      <span class="vl-innertext">or</span>
                    </div>

                    <div class="col">
                      <a href="#" class="fb btn">
                        <i class="fa fa-facebook fa-fw"></i> Login with Facebook
                       </a>
                      <a href="#" class="twitter btn">
                        <i class="fa fa-twitter fa-fw"></i> Login with Twitter
                      </a>
                      <a href="#" class="google btn"><i class="fa fa-google fa-fw">
                        </i> Login with Google+
                      </a>
                    </div>

                    <div class="col">
                      <div class="hide-md-lg">
                        <p>Or sign in manually:</p>
                      </div>

                      <input type="text" name="username" placeholder="Username" required>
                      <input type="password" name="password" placeholder="Password" required>
                      <input type="submit" value="Login">
                    </div>
                    
                  </div>
                </form>
                <div class="clear"></div>
                <div class="bottom-container">
                  <div class="row">
                    <div class="col">
                      <a href="#" style="color:white" class="btn">Sign up</a>
                    </div>
                    <div class="col">
                      <a href="#" style="color:white" class="btn">Forgot password?</a>
                    </div>
                  </div>
                </div>

             </div>
          </div>
       </div>
    </div>
 </div>
</div>