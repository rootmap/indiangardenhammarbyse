<aside class="col-md-3 right-sidebar">
	<ul class="sidebar_widgets">			
		<li class="widget blog-cat-w fx animated fadeInLeft" data-animate="fadeInLeft">
			<h3 class="widget-head">
				{{-- <span style="color: #09f; font-weight: bolder;" href="#">Logged : Fakhrul islam Talukder</span> --}}
			</h3>
			<div class="widget-content">
				<ul class="list list-ok alt">
					<li><a href="{{ url('user/dashboard') }}"><i class="fa fa-check"></i> Dashboard</a></li>
					<li><a href="{{ url('user/order/paid') }}"><i class="fa fa-check"></i> All Order</a></li>
					<li><a href="{{ url('user/order/paid') }}"><i class="fa fa-check"></i> Paid Order</a></li>
					<li><a href="{{ url('user/order/paid') }}"><i class="fa fa-check"></i> Pending Order</a></li>
					<li><a href="{{ url('user/order/paid') }}"><i class="fa fa-check"></i> Rejected Order</a></li>
					<li><a href="{{ url('user/profile') }}"><i class="fa fa-check"></i> Profile</a></li>
					<li><a href="{{ url('user/change-password') }}"><i class="fa fa-check"></i> Change Password</a></li>
				</ul>
			</div>
		</li>
	</ul>							
</aside>